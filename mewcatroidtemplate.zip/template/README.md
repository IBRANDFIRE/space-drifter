# NEWCATROID Runner — generic Catrobat/Pocket Code APK template

A reusable Android app skeleton that runs `.catrobat` projects inside a
WebView, using a JS engine (`runtime.js`) that interprets the project's
bricks directly on-device — no Catrobat/Pocket Code app install required,
and no build-time conversion step either. **To make a different game APK,
replace one file and rebuild.**

## What's in here

```
app/src/main/assets/
  index.html              <- host page, boots the engine
  fflate.js                <- small MIT-licensed zip-reading library (bundled, no CDN)
  catrobat-loader.js       <- unzips + parses the raw .catrobat file, in-browser
  runtime.js                <- the engine: brick interpreter + formula evaluator
  project/game.catrobat     <- YOUR GAME. Replace this file to change games.
app/src/main/java/...      <- MainActivity.java (fullscreen WebView host)
app/src/main/AndroidManifest.xml
app/build.gradle, build.gradle, settings.gradle, gradle.properties
tools/parse_project.py     <- optional: pre-bakes a project to JSON ahead of time (see below)
```

## 1. Swapping in a different game

Replace `app/src/main/assets/project/game.catrobat` with your own
`.catrobat` file (keep the filename `game.catrobat`), then rebuild. That's
it — no Python, no conversion step. The app reads and parses the raw
`.catrobat` zip itself the moment it launches.

Rename `applicationId` in `app/build.gradle` and `app_name` in
`res/values/strings.xml` per game if you're shipping more than one APK
from this template so they don't collide on a device.

## 2. Building the APK

**Option A — Android Studio (most reliable):** Open the `template/` folder
as a project. Studio will generate the Gradle wrapper automatically the
first time it syncs. Build → Build APK(s).

**Option B — command line with a system-installed Gradle:**
```
gradle assembleDebug
```
The unsigned/debug APK lands in `app/build/outputs/apk/debug/`.
(This repo doesn't ship `gradlew`/the wrapper jar, since that's a binary
file — either let Android Studio generate it, or use a Gradle you already
have installed.)

**CxxDroid / AndroLuaX:** this is a standard Gradle-based Android project
(WebView host + assets), not a raw single-file `.java` build, so CxxDroid's
built-in Java compiler alone won't produce this APK. You'll need Gradle
available in your build environment (e.g. Termux with Gradle installed) or
Android Studio on a desktop. Once built, the resulting `.apk` installs and
runs on any Android 5.0+ (API 21+) device — including via CxxDroid's
installer — same as any other APK.

## 3. (Optional) pre-baking a project instead

`tools/parse_project.py` still exists and still works — it converts a
`.catrobat` file into `project/project.json` + `project/media/` ahead of
time on your computer, instead of the app doing it on first launch. The
app checks for `project/game.catrobat` first and only falls back to
`project.json` if that file isn't present. There's no real reason to use
this unless you have a very large project and want to shave a fraction of
a second off first launch — the in-browser parse is fast for normal-sized
projects. For almost everyone: just replace `game.catrobat` and ignore
this tool.

## 4. Known limitations (things simplified or stubbed)

The engine covers the full common brick set (motion, looks, sound, pen,
variables/lists, control flow, broadcasts, cloning, basic physics). A few
things are intentionally out of scope for this template:

- **Custom "my blocks"** (`UserDefinedBrick`) are logged to the console but
  not executed — the definition-resolution logic wasn't built out.
- **Per-pixel color collision** (`COLLIDES_WITH_COLOR`, `COLOR_TOUCHES_COLOR`)
  always returns false — collision detection is bounding-box only.
- **Device storage bricks** (`Read/WriteVariableOnDevice`,
  `Read/WriteVariableToFile`, `Read/WriteListOnDevice`) use the WebView's
  `localStorage`, not real device files.
- **`WhenConditionScript`, `WhenBackgroundChangesScript`, `WhenBounceOffScript`**
  triggers are parsed but never started — their bricks won't run.
- **`GoToBrick`'s "random position" / "touch position" targeting** isn't
  resolved — it only works when pointed at another sprite by name.
- **Physics** is a simplified velocity/gravity/bounce model, not a real
  physics engine (no rotation-aware collision response between bodies).
- **`ArcBrick`, `TapAtBrick`/`TapForBrick`/`TouchAndSlideBrick`** (synthetic
  input playback) are no-ops.

None of these throw — a project using them keeps running, just without
that specific behavior. Check the browser/WebView JS console
(`chrome://inspect` on a connected device) to see exactly which bricks a
given project hits that aren't implemented, then extend the `switch` in
`runtime.js`'s `_runBrick()` — every case follows the same pattern.

## 5. How it works, briefly

`catrobat-loader.js` unzips your `.catrobat` file with `fflate` (bundled
locally, MIT license — see `THIRD_PARTY_LICENSES.txt`), parses `code.xml`
with the browser's built-in `DOMParser`, resolves Catrobat's XStream-style
`reference="../.."` pointers (used for shared variables/lists), and turns
your sprites' images/sounds into `blob:` URLs — all in memory, nothing
written to disk. `runtime.js` then compiles each script into a JS
generator function; one `yield` = one scheduler tick, so `Wait`,
`RepeatUntil`, and infinite loops cooperate with the render loop instead
of blocking it. `Formula.evaluate()` walks the same nested-formula
structure the XML formula trees became, dispatching on `OPERATOR` /
`FUNCTION` / `SENSOR` / `USER_VARIABLE` / `USER_LIST` / `COLLISION_FORMULA`.
