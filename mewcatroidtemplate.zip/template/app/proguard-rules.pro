# Add project-specific ProGuard rules here.
-keep class org.newcatroid.runner.** { *; }
