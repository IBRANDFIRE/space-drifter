/* catrobat-loader.js
 * Reads a raw .catrobat file (a zip: code.xml + image/sound folders) directly
 * in the WebView and produces the same project structure that runtime.js's
 * Engine expects — no Python pre-processing step. This is a JS port of
 * tools/parse_project.py; see that file's comments for the "why" behind the
 * reference-resolution algorithm.
 */
(function () {
'use strict';

const MIME = {
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
  webp: 'image/webp', bmp: 'image/bmp',
  mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4', aac: 'audio/aac',
};

function text(el) { return el && el.textContent != null ? el.textContent : ''; }
function firstChildByTag(el, tag) {
  if (!el) return null;
  for (const c of el.children) if (c.tagName === tag) return c;
  return null;
}
function childrenByTag(el, tag) {
  if (!el) return [];
  return [...el.children].filter(c => c.tagName === tag);
}
function firstDescendantByTag(el, tag) {
  return el ? el.querySelector(tag) : null;
}

// ---------------------------------------------------------------------
// 1. Reference resolution (same relative-XPath algorithm as the Python tool)
// ---------------------------------------------------------------------
function resolveReference(elem, refPath) {
  let node = elem;
  const segments = refPath.split('/');
  let i = 0;
  while (i < segments.length && segments[i] === '..') {
    node = node.parentElement;
    if (!node) return null;
    i++;
  }
  for (; i < segments.length; i++) {
    const seg = segments[i];
    if (seg === '') continue;
    const m = /^([A-Za-z0-9_]+)(?:\[(\d+)\])?$/.exec(seg);
    if (!m) return null;
    const tag = m[1], idx = m[2] ? parseInt(m[2], 10) : 1;
    const matches = childrenByTag(node, tag);
    if (idx > matches.length || idx < 1) return null;
    node = matches[idx - 1];
  }
  return node;
}

function resolveAllReferences(root, maxPasses = 6) {
  for (let pass = 0; pass < maxPasses; pass++) {
    const refs = [...root.querySelectorAll('[reference]')];
    if (refs.length === 0) break;
    let progressed = false;
    for (const elem of refs) {
      const refPath = elem.getAttribute('reference');
      const target = resolveReference(elem, refPath);
      if (!target) continue;
      const clone = target.cloneNode(true);
      // rename the clone to the referencing element's tag, drop the pointer
      const renamed = clone.ownerDocument.createElement(elem.tagName);
      renamed.innerHTML = clone.innerHTML;
      for (const attr of clone.attributes) {
        if (attr.name !== 'reference') renamed.setAttribute(attr.name, attr.value);
      }
      elem.replaceWith(renamed);
      progressed = true;
    }
    if (!progressed) break;
  }
  return root;
}

// ---------------------------------------------------------------------
// 2. Formula tree
// ---------------------------------------------------------------------
function parseFormula(el) {
  if (!el) return null;
  const node = { type: text(firstChildByTag(el, 'type')), value: text(firstChildByTag(el, 'value')) };
  const left = firstChildByTag(el, 'leftChild');
  const right = firstChildByTag(el, 'rightChild');
  if (left && left.children.length) node.left = parseFormula(left);
  if (right && right.children.length) node.right = parseFormula(right);
  const extra = firstChildByTag(el, 'additionalChildren');
  if (extra && extra.children.length) node.extra = [...extra.children].map(parseFormula);
  return node;
}

// ---------------------------------------------------------------------
// 3. Bricks / scripts (tag names verified against real Catrobat 1.x export)
// ---------------------------------------------------------------------
function parseBrick(el) {
  const brick = { type: el.getAttribute('type') || el.tagName };

  const fl = firstChildByTag(el, 'formulaList');
  if (fl) {
    brick.formulas = {};
    for (const f of childrenByTag(fl, 'formula')) {
      brick.formulas[f.getAttribute('category') || 'DEFAULT'] = parseFormula(f);
    }
  }

  const look = firstChildByTag(el, 'look');
  if (look) { const n = firstChildByTag(look, 'name'); if (n) brick.look = text(n); }

  const sound = firstChildByTag(el, 'sound');
  if (sound) { const n = firstChildByTag(sound, 'name'); if (n) brick.sound = text(n); }

  const uv = firstChildByTag(el, 'userVariable');
  if (uv) { const n = firstDescendantByTag(uv, 'name'); brick.variable = n ? text(n) : null; }

  let ul = firstChildByTag(el, 'userList');
  if (!ul) ul = firstChildByTag(el, 'userDataList');
  if (ul) { const n = firstDescendantByTag(ul, 'name'); brick.list = n ? text(n) : null; }

  for (const tag of ['broadcastMessage', 'sceneToStart', 'sceneForTransition',
                      'spinnerSelection', 'selection', 'type', 'alignmentSelection',
                      'message', 'spriteToClone', 'sprite']) {
    const e = firstChildByTag(el, tag);
    if (e) brick[tag] = text(e);
  }

  const ifBody = firstChildByTag(el, 'ifBranchBricks');
  if (ifBody) brick.bricks = childrenByTag(ifBody, 'brick').map(parseBrick);
  const elseBody = firstChildByTag(el, 'elseBranchBricks');
  if (elseBody) brick.elseBricks = childrenByTag(elseBody, 'brick').map(parseBrick);
  const loopBody = firstChildByTag(el, 'loopBricks');
  if (loopBody) brick.bricks = childrenByTag(loopBody, 'brick').map(parseBrick);

  return brick;
}

function parseScript(el) {
  const bl = firstChildByTag(el, 'brickList');
  const script = { type: el.getAttribute('type'), bricks: bl ? childrenByTag(bl, 'brick').map(parseBrick) : [] };
  const rm = firstChildByTag(el, 'receivedMessage');
  if (rm) script.receivedMessage = text(rm);
  return script;
}

function parseUserData(container, tag) {
  if (!container) return [];
  return childrenByTag(container, tag).map(e => {
    const n = firstDescendantByTag(e, 'name');
    return { name: n ? text(n) : '' };
  });
}

function parseObject(el) {
  const looks = childrenByTag(firstChildByTag(el, 'lookList'), 'look')
    .map(l => ({ name: l.getAttribute('name'), fileName: l.getAttribute('fileName') }));
  const sounds = childrenByTag(firstChildByTag(el, 'soundList'), 'sound')
    .map(s => ({ name: s.getAttribute('name'), fileName: s.getAttribute('fileName') }));
  const scripts = childrenByTag(firstChildByTag(el, 'scriptList'), 'script').map(parseScript);
  return {
    name: el.getAttribute('name'),
    type: el.getAttribute('type'),
    looks, sounds, scripts,
    variables: parseUserData(firstChildByTag(el, 'userVariables'), 'userVariable'),
    lists: parseUserData(firstChildByTag(el, 'userLists'), 'userList'),
  };
}

function parseScene(el) {
  const ol = firstChildByTag(el, 'objectList');
  return {
    name: text(firstChildByTag(el, 'name')),
    objects: ol ? childrenByTag(ol, 'object').map(parseObject) : [],
  };
}

// ---------------------------------------------------------------------
// 4. Top level: unzip, parse, wire up media as blob URLs
// ---------------------------------------------------------------------
async function load(arrayBuffer) {
  const bytes = new Uint8Array(arrayBuffer);
  const files = fflate.unzipSync(bytes); // { path: Uint8Array }

  let codeXmlPath = Object.keys(files).find(p => p === 'code.xml' || p.endsWith('/code.xml'));
  if (!codeXmlPath) throw new Error('code.xml not found inside the .catrobat file');
  const xmlText = new TextDecoder('utf-8').decode(files[codeXmlPath]);
  const doc = new DOMParser().parseFromString(xmlText, 'application/xml');
  const perr = doc.querySelector('parsererror');
  if (perr) throw new Error('code.xml failed to parse: ' + perr.textContent.slice(0, 200));

  const root = doc.documentElement;
  resolveAllReferences(root);

  const header = {};
  const headerEl = firstChildByTag(root, 'header');
  if (headerEl) for (const c of headerEl.children) header[c.tagName] = text(c);

  const scenesEl = firstChildByTag(root, 'scenes');
  const scenes = scenesEl ? childrenByTag(scenesEl, 'scene').map(parseScene) : [];

  const globalVars = parseUserData(firstChildByTag(root, 'programVariableList'), 'userVariable');
  const globalLists = parseUserData(firstChildByTag(root, 'programListOfLists'), 'userList');

  // Media: first zip entry matching each bare filename wins (mirrors the
  // Python tool), turned into object-URL blobs — nothing touches disk.
  const byBaseName = new Map();
  for (const path of Object.keys(files)) {
    if (path.endsWith('/') || path === codeXmlPath) continue;
    const base = path.split('/').pop();
    if (!base || base.startsWith('.') || base === '.nomedia') continue;
    if (!byBaseName.has(base)) byBaseName.set(base, path);
  }
  const blobUrlCache = new Map(); // base filename -> object URL
  function urlFor(fileName) {
    if (!fileName) return '';
    if (blobUrlCache.has(fileName)) return blobUrlCache.get(fileName);
    const path = byBaseName.get(fileName);
    if (!path) { console.warn('[catrobat-loader] media not found in zip:', fileName); return ''; }
    const ext = fileName.split('.').pop().toLowerCase();
    const blob = new Blob([files[path]], { type: MIME[ext] || 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    blobUrlCache.set(fileName, url);
    return url;
  }
  for (const scene of scenes) {
    for (const obj of scene.objects) {
      for (const look of obj.looks) look.file = urlFor(look.fileName);
      for (const sound of obj.sounds) sound.file = urlFor(sound.fileName);
    }
  }

  return {
    header: {
      programName: header.programName || 'Untitled',
      screenWidth: Math.round(parseFloat(header.screenWidth) || 480),
      screenHeight: Math.round(parseFloat(header.screenHeight) || 800),
      screenMode: header.screenMode || 'STRETCH',
      landscapeMode: header.landscapeMode === 'true',
    },
    scenes,
    globals: { variables: globalVars, lists: globalLists },
  };
}

window.CatrobatLoader = { load };
})();
